import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { Pipe, PipeTransform } from '@angular/core';

@Component({
  selector: 'app-templatedriven',
  templateUrl: './templatedriven.component.html',
  styleUrls: ['./templatedriven.component.css']
})
export class TemplatedrivenComponent implements OnInit {
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
//   userName='';
//   defaultc='Angular';
//   defaultGender='Male';

//   //obj form
// formData={
//   username: "",
//   course: "",
//   customRadio: "",
//   email: "",
//   phone:"",
//   note:'',
//   image:''
// }
// // obj
// genders=[
//   {
//     id:'1',value:'Male'
//   },
//     {
//       id:'2',value:'Female'
//   }
//   ]
//   form: any;

//   constructor() { }

//   ngOnInit() {
//   }
//   submitted=false;

//   fun_rest(){
//   // this.formData.reset()
//   }
//   onSave(form:NgForm){
//     // console.log(form)
//     console.log(form);
//     // click than true
//     this.submitted=true;
//   this.formData.username=form.value.UserName;
//   console.log(this.formData.username=form.value.Username);
//   console.log(this.formData.email=form.value.email);
//   console.log(this.formData.customRadio=form.value.customRadio);
//   console.log(this.formData.course=form.value.course);
//   console.log(this.formData.phone=form.value.phone);
//   console.log(this.formData.note=form.value.note);

//   console.log(this.formData.image=form.value.customFile) // return form.value.Username;
// // this.form.clear()
// }

}
