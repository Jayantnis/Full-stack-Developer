// import { AbstractControl } from "@angular/forms";

// export function userValidValidator(control:AbstractControl):{[key:string]:any; any: any}|null{
// const names=/test/.test(control.value);
// return names?{'userInvalid':true}:null:
// }
