import { Injectable } from '@angular/core';
import { idText } from 'typescript';

@Injectable({
  providedIn: 'root'
})
export class DesignutilityService {

  constructor() { }
  active_button()
  {
    alert("depandence service Activited")
  }
  product="ACTIVE PC";

  // obj
  product_phone={
    id:'1',
    class:'Rahul'
  }
  // array of obj
  // product_ArrayObj=[
  //   {id:'@$342',class:'RAJU'},
  //   {id:'%^%&^%',class:'ROHIT'}
  // ]
}
