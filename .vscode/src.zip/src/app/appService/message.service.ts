export class MessageService
{

  message_fun(){
    alert("Hello CARD")
    alert('Main Service Access')
  }
}
