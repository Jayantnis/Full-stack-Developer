import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DataloadComponent } from './dataload.component';

describe('DataloadComponent', () => {
  let component: DataloadComponent;
  let fixture: ComponentFixture<DataloadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DataloadComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DataloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
