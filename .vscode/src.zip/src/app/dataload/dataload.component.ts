import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { home } from './modal/home.model';
import { NEVER } from 'rxjs';
@Component({
  selector: 'app-dataload',
  templateUrl: './dataload.component.html',
  styleUrls: ['./dataload.component.css']
})
export class DataloadComponent implements OnInit {
// home
  data:any;
d:boolean=false;
  dataarray:any=[];
  home=new home();

  ngOnInit() {
  // this.ge
  this.dataarray.push(this.home);
    // throw new Error('Method not implemented.');
  }

  get nameFun()
  {
    return this.dataarray.get('dataarray.name');
  }
  // add new obj
  addForm(){
    this.home=new home();
    this.dataarray.push(this.home);
  }


  onsubmit(){
    console.log(this.dataarray)
  }

  removeForm(index:number){
    this.dataarray.splice(index);
  }

}





