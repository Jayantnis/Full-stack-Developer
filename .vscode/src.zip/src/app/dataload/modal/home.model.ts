export class home{
  name:any;salary:any;age:any;id:any;
}
