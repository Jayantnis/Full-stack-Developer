import { DesignutilityService } from './../appService/designutility.service';
import { Component, OnInit } from '@angular/core';
// service import
import { MessageService } from '../appService/message.service';
@Component({
  selector: 'app-card1',
  templateUrl: './card1.component.html',
  styleUrls: ['./card1.component.css']
})
export class Card1Component implements OnInit {

  // depandency injection
  constructor(private _megSerive:DesignutilityService){  }
  product='';
  product_phone={};
  product_arrobj=[{}];

  ngOnInit(): void
  {
    this.product= this._megSerive.product;
    this.product_phone=this._megSerive.product_phone.id;
    this.product_phone=this._megSerive.product_phone.class;
    // this.product_arrobj=this._megSerive.product_ArrayObj;
  }



  // fun(){
  //   alert("Hello CARD 1")
  // }

  // custom serive
  btnClick(){
    const msgService=new MessageService();
    msgService.message_fun();
  }

  //depandence service
  bt_fun(){
    this._megSerive.active_button();
  }
}
