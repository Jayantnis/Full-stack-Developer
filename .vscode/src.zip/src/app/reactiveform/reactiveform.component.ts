import { NumberFormatStyle } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';

// import { userValidValidator } from '../validation-rules/users';
@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css']
})
export class ReactiveformComponent implements OnInit {
 public loginForm:FormGroup|any;
  ngOnInit(): void {

    this.loginForm=new FormGroup({
      user:new FormControl(null,[Validators.required,Validators.minLength(2),Validators.pattern('[a-zA-Z].*')]),
      phone:new FormControl(null,[Validators.required]),
      email:new FormControl(null,[Validators.required,Validators.minLength(9),Validators.email]),
      'skills':new FormArray([new FormControl(null,Validators.required)]),

});

}

  title='Angular Reactive Form';



  // get any fun another name
  get nameFun() {//retrival child control path
    return this.loginForm.get('user');//path name of user group
  }

  get emailFun()
  {
    return this.loginForm.get('email');
  }
  //  num:number|any;
  get numberFun()
  {
    return this.loginForm.get('phone');
  }
  // fun(){}
  //add new skillls
  onAddSkills(){
    const control=new FormControl('',Validators.required);
  //  (<FormArray>this.loginForm.get('skills')).push(control);
    (<FormArray>this.loginForm.get('skills')).push(this.onAddSkills);
  }


// Remove index
  onRemoveSkills(index:number)
  {  (<FormArray>this.loginForm.get('skills')).removeAt(index);  }



  rectiveform()
  {
    console.warn(this.loginForm.value);

    this.formData.user=this.loginForm.value.user;
    this.formData.email=this.loginForm.value.email;
    this.formData.phone=this.loginForm.value.phone;

    console.log(this.formData.user=this.loginForm.value.user);
    console.log(this.formData.email=this.loginForm.value.email);
    console.log(this.formData.phone=this.loginForm.value.phone);

  }

// object
//obj form
formData={
  user: "",
  phone: "",
  email: "",
}

}


















// error occurences
//   myRectiveForm: FormGroup|any;
//   notAllowedNames=['abs','Anup'];
//   ngOnInit(): void
//   {
//      // js object passing
//      this.myRectiveForm=new FormGroup
//      ({
//       //  'username':new FormControl(null,[Validators.required,this.anname.bind(this)]),//or initial values 'null'
//        'email':new FormControl(null,[Validators.required,Validators.email]),
//        'course':new FormControl('HTML'),
//        'customRadio':new FormControl('Male'),
//        'skills':new FormArray([
//         new FormControl(null,Validators.required)
//        ])
//      });
//   }

//   anname(control:FormControl){
//     if(this.notAllowedNames.indexOf(control.value)!==-1){
//       return {'nameIsNotAllow':true};
//     }

//   }

//   onsubmitReactiveForm(){
// console.log(this.myRectiveForm)
//   }


//   onAddSkills(){
//     const control=new FormControl(null,Validators.required);

//     (<FormArray>this.myRectiveForm.get('skills')).push(control);
//   }

