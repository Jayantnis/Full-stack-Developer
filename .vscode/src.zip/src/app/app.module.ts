import { DesignutilityService } from './appService/designutility.service';
import { HomeComponent } from './home/home.component';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
// import { Pipe } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { TemplatedrivenComponent } from './templatedriven/templatedriven.component';
import { ReactiveformComponent } from './reactiveform/reactiveform.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PasswordmatchingComponent } from './passwordmatching/passwordmatching.component';
import { Card1Component } from './card1/card1.component';
import { Card2Component } from './card2/card2.component';
// import { UsersComponent } from './validation-rules/users/users.component';
// import {HttpClientModule} from '@angular/common/http';

// import masking attech
import { MatFormFieldModule } from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import { NgxMaskModule } from 'ngx-mask';
import {MatSelectModule} from '@angular/material/select';
import { MatOptionModule } from '@angular/material/core';
import {MatIconModule} from '@angular/material/icon';
import { GoComponent } from './go/go.component';

// impo
@NgModule({
  declarations: [
    AppComponent,HomeComponent,AboutComponent, TemplatedrivenComponent, ReactiveformComponent, PasswordmatchingComponent, Card1Component, Card2Component, GoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,RouterModule,FormsModule,MatIconModule,MatSelectModule,MatOptionModule,ReactiveFormsModule,MatFormFieldModule,MatInputModule,NgxMaskModule.forRoot()
    // ,HttpClientModule
  ],
  providers: [DesignutilityService],
  bootstrap: [AppComponent]
})
export class AppModule { }
