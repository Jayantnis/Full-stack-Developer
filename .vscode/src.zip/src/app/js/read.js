console.log("check number of arr")

let x = 7,
    arr = [5, 2, 5, 7, 2, 9, 7];
