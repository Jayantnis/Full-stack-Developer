import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';

@Component({
  selector: 'app-passwordmatching',
  templateUrl: './passwordmatching.component.html',
  styleUrls: ['./passwordmatching.component.css']
})
export class PasswordmatchingComponent implements OnInit {
/*---------------- new set form----------------*/
// password matching custome validations
myForm!: FormGroup

  constructor(private fb: FormBuilder) {}

  ngOnInit()
  {
    this.myForm = this.fb.group({
      password: this.fb.control(null),
      confirmPassword: this.fb.control(null),
    }, {
      validators: this.controlValuesAreEqual('password', 'confirmPassword')
    })
  }


  private controlValuesAreEqual(controlNameA: string, controlNameB: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const formGroup = control as FormGroup
      const valueOfControlA = formGroup.get(controlNameA)?.value
      const valueOfControlB = formGroup.get(controlNameB)?.value

      if (valueOfControlA === valueOfControlB) {
        return {valueOfControlA};
      } else {
        return { valuesDoNotMatch: true }
      }
    }
  }
}
// myPasswordMatch!:FormGroup;
// constructor(private fb:FormBuilder){}

// ngOnInit()
// {
//   this.myPasswordMatch=this.fb.group({
//     passwordType:this.fb.control(null),
//     confirmPassword:this.fb.control(null),
//   },
//   {
//     Validators:this.controlMatchPassword('passwordType','confirmPassword')
//   })
// //  throw new Error('Method not implemented.');
// }
// // validators at abstract validator
// private controlMatchPassword(controlPassA:string,controlPassB:string):ValidatorFn{
//   // validations error as key value pair
// return (control:AbstractControl):ValidationErrors|null=>{
//  const formGroup=control as FormGroup
//  const valueOfControlFirst=formGroup.get(controlPassA)?.value;
//  const valueOfControlSecond=formGroup.get(controlPassB)?.value;

// if(valueOfControlFirst==valueOfControlSecond)
// {
//   return null;
// }else{

// // valuesDoNotMatch:Boolean;
//   return {valuesDoNotMatch:true}

// }
// }
// }
