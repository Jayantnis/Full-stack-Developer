import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PasswordmatchingComponent } from './passwordmatching.component';

describe('PasswordmatchingComponent', () => {
  let component: PasswordmatchingComponent;
  let fixture: ComponentFixture<PasswordmatchingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PasswordmatchingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PasswordmatchingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
