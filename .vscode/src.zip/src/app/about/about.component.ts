import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
// import { Home } from './model/home.model';
// import{home}from './model/home.model';
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  courses(courses: any): any {
    throw new Error('Method not implemented.');
  }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  constructor(private fb:FormBuilder) {}

  form = this.fb.group({
    lessons: this.fb.array([]),
    title: ['', {
      validators: [
          Validators.required,
          Validators.minLength(5),
          Validators.maxLength(60)
      ],
      asyncValidators: [courseTitleValidator(this.courses)],
      updateOn: 'blur'
  }],
  releasedAt: [new Date(), Validators.required],
  category: ['BEGINNER', Validators.required],
  downloadsAllowed: [false, Validators.requiredTrue],
  longDescription: ['', [Validators.required, Validators.minLength(3)]]
});


get lessons() {
  return this.form.controls["lessons"] as FormArray;

}

addLesson() {
  const lessonForm = this.fb.group({
    title: ['', Validators.required],
    level: ['', Validators.required]
  });
  this.lessons.push(lessonForm);
}

deleteLesson(lessonIndex: number) {
  this.lessons.removeAt(lessonIndex);
}
}

function courseTitleValidator(courses: any): any {
  throw new Error('Function not implemented.');
}
// // Home!:any;
//   home=new Home();
//   dataArray=[];
//   constructor(){}

//   ngOnInit() {
//     this.dataArray.push(this.home);//this.home
//     // throw new Error('Method not implemented.');
//   }


//   onSubmit(){}
  // ngOnInit(): void {
  //   throw new Error('Method not implemented.');
  // }

  // name = 'Dynamic Add Fields';
  // values = [];

  // removevalue(i){
  //   this.values.splice(i,1);
  // }

  // addvalue(){
  //   this.values.push({value: ""});
  // }

//
//   form = this.fb.group({
//     lessons: this.fb.array([])
// });

// constructor(private fb:FormBuilder) {}
//   ngOnInit(): void {
//     throw new Error('Method not implemented.');
//   }

// get lessons() {
//   return this.form.controls["lessons"] as FormArray;
// }

// addLesson() {
//   const lessonForm = this.fb.group({
//     title: ['', Validators.required],
//     level: ['beginner', Validators.required]
//   });
//   this.lessons.push(lessonForm);
// }

// deleteLesson(lessonIndex: number) {
//   this.lessons.removeAt(lessonIndex);
// }





