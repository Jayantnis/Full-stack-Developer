import { DesignutilityService } from './../appService/designutility.service';
import { Component, OnInit } from '@angular/core';
// service
import { MessageService } from '../appService/message.service';

@Component({
  selector: 'app-card2',
  templateUrl: './card2.component.html',
  styleUrls: ['./card2.component.css']
})
export class Card2Component implements OnInit {

  // depandency injection
  constructor(private _mesActive:DesignutilityService)
  {

  }

  product='';
  ngOnInit(): void
  {
    this.product= this._mesActive.product;
  }
  // fun(){
  //   alert("Hello CARD 1")
  // }
  btn_fun(){
    const msgService=new MessageService();
    msgService.message_fun();
  }

  //depandence service
  bt_fun(){
    this._mesActive.active_button();
  }
}
