import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-go',
  templateUrl: './go.component.html',
  styleUrls: ['./go.component.css']
})
export class GoComponent implements OnInit {
  name = 'Angular';

  productForm: FormGroup;

  constructor(private fb:FormBuilder) {

    this.productForm = this.fb.group({
      // name: new FormControl('',[Validators.required,Validators.minLength(2)]),
      // phone:new FormControl(null,[Validators.required]),
      // email:new FormControl(null,[Validators.required,Validators.minLength(9),Validators.email]),
      id: this.fb.array([],Validators.required),

      // set:new FormControl(,[Validators.required,Validators.minLength(2),Validators.pattern('[a-zA-Z].*')]),

    });
  }

  threeInputFun() : FormArray {
    return this.productForm.get("id") as FormArray;
  }
// new FormControl(null,[Validators.required,Validators.minLength(2),Validators.pattern('[a-zA-Z].*')])
  newQuantity(): FormGroup {
    return this.fb.group({ name:''})
  }
  addQuantity() {
    this.threeInputFun().push(this.newQuantity());
  }


  get nameFun(){
    return this.productForm.get('id')as FormArray;
  }


  removeQuantity(i:number) {
    this.threeInputFun().removeAt(i);
  }

  onSubmit() {
    console.log(this.productForm.value);
  }

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

}
