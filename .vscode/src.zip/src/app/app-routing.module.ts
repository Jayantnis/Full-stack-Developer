import { GoComponent } from './go/go.component';
import { PasswordmatchingComponent } from './passwordmatching/passwordmatching.component';
import { ReactiveformComponent } from './reactiveform/reactiveform.component';
import { TemplatedrivenComponent } from './templatedriven/templatedriven.component';
import { AboutComponent } from './about/about.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { Card1Component } from './card1/card1.component';
import { Card2Component } from './card2/card2.component';

const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'about',component:AboutComponent},
  {path:'templatedriven',component:TemplatedrivenComponent},
  {path:'reactiveform',component:ReactiveformComponent},
  {path:'passwordmatching',component:PasswordmatchingComponent},
  {path:'card1',component:Card1Component},
  {path:'card2',component:Card2Component},
  {path:'go',component:GoComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
