import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';

@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css']
})
export class ReactiveformComponent implements OnInit {

  constructor(){ }
// error occurences
  myRectiveForm: FormGroup|any;
  notAllowedNames=['abs','Anup'];
  ngOnInit(): void
  {
     // js object passing
     this.myRectiveForm=new FormGroup
     ({
      //  'username':new FormControl(null,[Validators.required,this.anname.bind(this)]),//or initial values 'null'
       'email':new FormControl(null,[Validators.required,Validators.email]),
       'course':new FormControl('HTML'),
       'customRadio':new FormControl('Male'),
       'skills':new FormArray([
        new FormControl(null,Validators.required)
       ])
     });
  }

  anname(control:FormControl){
    if(this.notAllowedNames.indexOf(control.value)!==-1){
      return {'nameIsNotAllow':true};
    }

  }

  onsubmitReactiveForm(){
console.log(this.myRectiveForm)
  }


  onAddSkills(){
    const control=new FormControl(null,Validators.required);

    (<FormArray>this.myRectiveForm.get('skills')).push(control);
  }
}
